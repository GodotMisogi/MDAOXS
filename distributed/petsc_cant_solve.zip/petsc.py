from petsc4py import PETSc
from mpi4py import MPI
import numpy as np
import scipy.io as si
rank = PETSc.COMM_WORLD.rank
num_ranks = PETSc.COMM_WORLD.size
#rows = np.load('rows.npy')
#cols = np.load('cols.npy')
#data = np.load('data.npy')
Amat = si.loadmat('A.mat')['A']
N = 8

A = PETSc.Mat()
A.create(comm=MPI.COMM_WORLD)
A.setSizes([N, N])
A.setType("mpiaij")
A.setUp()
A.setValues(list(np.arange(N)),list(np.arange(N)),Amat)

"""
for idx, (row, col) in enumerate(zip(rows, cols)):
    A.setValue(row, col, data[idx])
A.setValue(N-2,N-2,0)
A.setValue(N-1,N-1,0)
"""
A.assemble()

si.savemat('A',{'A':A[:,:]})
x,c = A.getVecs()
x.set(0)
c.set(0)
c.setValue(N-4,-1)
ksp = PETSc.KSP()
ksp.create(MPI.COMM_WORLD)
ksp.setType('gmres')
ksp.setOperators(A)
ksp.setFromOptions()
ksp.solve(c, x)
#print(ksp.getResidualNorm())
local_x = np.zeros(N)

id_start, id_end = A.getOwnershipRange()
#print("processors %d"%rank," owns %d,%d"%(id_start,id_end))
local_x[id_start:id_end] = x[...]

global_x = np.zeros(N)
#print(np.array(x))
MPI.COMM_WORLD.Reduce([local_x,MPI.DOUBLE],[global_x,MPI.DOUBLE],op=MPI.SUM,root=0)
#print(x[:])
if rank == 0:
    print(np.dot(A[:,:],global_x)-c[:])
